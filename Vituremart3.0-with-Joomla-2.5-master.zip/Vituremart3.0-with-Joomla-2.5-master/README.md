# Vituremart3.0-with-Joomla-2.5
Paysolutions Payment
เพิ่มเติม 
1.หลังจากทำการดาวน์โหลด ให้ทำการแตกไฟล์ 
2.ให้ทำการ Zip ไฟล์ paysolutions 
3.จากนั้นทำตามคู่มือที่แนบ
