# Woo-Commerce2.5.xx-3.2.1-with-Wordpress-4.5.2-4.8.3
Paysolutions Payment
เพิ่มเติม ***
1.ให้ทำการติดตั้ง Woo-Commerce ในเวอร์ชั่นที่กำหนด ก่อนทำการลง Paysolutions payment 
2.หลังจากทำการดาวน์โหลด ให้ทำการแตกไฟล์ 
3.หลังจากนั้นให้ทำการ Zip โฟรเดอร์ pst-woocommerce-paysolutions-payment-gateway
4.และจึงทำตามคู่มือที่แนบต่อไปครับ
