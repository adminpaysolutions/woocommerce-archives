<p align="center"><a href='https://www.paysolutions.asia/'><img src='http://paysolutions.asia/assets/images/paysolution-logo@2x.png'></a></p>

**Paysolutions** payment solution for your store builders working on the Woo Commerce.

## Installation Instructions
**Download extension and unzip file**

1. Upload the plugin files in your wordpress admin
> -> Plugins  -> add new <br />
> <img src='https://www.thaiepay.com/images/woo34x/woo34x-1.png' > <br /><br />

2. Install Plugin
> <img src='https://www.thaiepay.com/images/woo34x/woo34x-2.png' > <br /><br />
> -> Choose File paysolutions.zip <br />
> -> Install now <br />
> -> Activate Plugin <br />

3. Activate Plugin.
> in the list Plugin Activated, click settings Paysolution Payment Gateway <br>
> <img src='https://www.thaiepay.com/images/woo34x/woo34x-3.png' > <br /><br />

4. Enter the below data for setting page.
> <img src='https://www.thaiepay.com/images/woo34x/woo34x-4.png' > <br /><br />
> Save Change

---------------------------------------------------------------------------------------------


**Comfirm Orders**
> <img src='https://www.thaiepay.com/images/woo34x/woo34x-5.png' > <br /><br />
> <img src='https://www.thaiepay.com/images/woo34x/woo34x-6.png' > <br /><br />
> <img src='https://www.thaiepay.com/images/woo34x/woo34x-7.png' > <br /><br />


## Submit the issue
**We are support for 8 currencies**
1. AUD 
2. CHF
3. EUR
4. GBP
5. HKD
6. JPY
7. SGD
8. THB
9. USD
